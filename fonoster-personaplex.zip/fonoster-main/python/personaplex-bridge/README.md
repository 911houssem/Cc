# جسر Fonoster ⇄ NVIDIA PersonaPlex-7B

يستبدل سلسلة STT → LLM → TTS بنموذج واحد full-duplex (صوت داخل، صوت خارج).

```
المتصل ⇄ Fonoster (AppBridge) ⇄ bridge.py ⇄ PersonaPlex (moshi.server على GPU)
```

## التشغيل
1. اقبل رخصة النموذج على https://huggingface.co/nvidia/personaplex-7b-v1 وخذ `HF_TOKEN`.
2. `cp .env.example .env` واملأ `APP_SIGNING_SECRET` و`HF_TOKEN`.
3. `docker compose -f compose.personaplex.yaml up -d` (يحتاج GPU بذاكرة 24GB أو أكثر).
4. في Fonoster أنشئ تطبيقاً من نوع `STREAM`:
   - `url`: `ws://personaplex-bridge:3000` (أو `wss://` العام)
   - `protocol`: `fonoster`
   - `audio`: `{ "codec": "pcm16", "rate": 24000 }`  ← مهم: نفس تردد النموذج، بلا إعادة أخذ عينات
   - اربط رقماً بهذا التطبيق.

## الإعداد
| المتغير | المعنى |
| :-- | :-- |
| `PERSONAPLEX_VOICE` | الصوت (`NATF2.pt`...) |
| `PERSONAPLEX_TEXT_PROMPT` | شخصية النموذج ودوره |
| `PERSONAPLEX_GATE_RMS` | يكتم ضجيج الخط إن ظهر هذيان في الصمت |
| `MAX_CALL_SECONDS` | سقف مدة المكالمة |

يمكن تجاوز الصوت والشخصية لكل مكالمة عبر metadata: `personaplex_voice` و`personaplex_text_prompt`.

## حدود يجب معرفتها
- النموذج لا يدعم **استدعاء الأدوات** (الحجز، التحويل...) ولا قاعدة المعرفة؛ ميزات Autopilot هذه لا تعمل معه.
- لغته الأساسية الإنجليزية؛ الدعم العربي/الدارجة غير مضمون: اختبره قبل أي عميل.
- المقاييس والفوترة وسجلات النص في Fonoster لا ترى هذه المكالمات كمكالمات Autopilot.
