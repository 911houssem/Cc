"""Fonoster stream app that answers calls with NVIDIA PersonaPlex-7B.

PersonaPlex is a full-duplex speech-to-speech model: it hears the caller and speaks back in one
model, so there is no STT -> LLM -> TTS cascade here. This app is the bridge:

    caller <-> Fonoster (AppBridge) <-> this app <-> PersonaPlex server (moshi.server, GPU)

Fonoster side: fonoster.session.v1, pcm16 frames (24 kHz recommended, nothing to resample).
PersonaPlex side: ws://<host>:8998/api/chat?voice_prompt=...&text_prompt=...; every binary
message starts with one kind byte: 0x00 handshake, 0x01 audio (Ogg Opus, 24 kHz), 0x02 text.
"""
from __future__ import annotations

import asyncio
import logging
import os
from urllib.parse import quote

import numpy as np
import sphn  # Kyutai's Ogg/Opus codec, the one moshi itself uses
import websockets

from fonoster.voice import VoiceServer

logger = logging.getLogger("personaplex-bridge")

MODEL_RATE = 24_000          # PersonaPlex / Mimi sample rate
CHUNK_SAMPLES = 1_920        # 80 ms at 24 kHz: PersonaPlex's frame size
KIND_HANDSHAKE, KIND_AUDIO, KIND_TEXT = 0x00, 0x01, 0x02

PERSONAPLEX_URL = os.environ.get("PERSONAPLEX_URL", "ws://personaplex:8998").rstrip("/")
VOICE_PROMPT = os.environ.get("PERSONAPLEX_VOICE", "NATF2.pt")
TEXT_PROMPT = os.environ.get(
    "PERSONAPLEX_TEXT_PROMPT",
    "You are a friendly phone receptionist. Answer briefly and politely.",
)
SEED = os.environ.get("PERSONAPLEX_SEED")
MAX_CALL_SECONDS = int(os.environ.get("MAX_CALL_SECONDS", "900"))
CONNECT_TIMEOUT = float(os.environ.get("PERSONAPLEX_CONNECT_TIMEOUT", "30"))
# Full-duplex models can babble on line noise; frames quieter than this RMS are sent as silence.
# 0 disables the gate. Typical phone noise floor: 50-150 (int16 scale).
GATE_RMS = float(os.environ.get("PERSONAPLEX_GATE_RMS", "0"))


def resample(pcm: np.ndarray, src: int, dst: int) -> np.ndarray:
    """Linear resampling of a float32 mono signal (fine for narrowband phone audio)."""
    if src == dst or pcm.size == 0:
        return pcm
    n = max(1, round(pcm.size * dst / src))
    return np.interp(np.linspace(0, pcm.size - 1, n), np.arange(pcm.size), pcm).astype(np.float32)


def model_url(text_prompt: str, voice_prompt: str) -> str:
    query = f"voice_prompt={quote(voice_prompt)}&text_prompt={quote(text_prompt)}"
    if SEED:
        query += f"&seed={quote(SEED)}"
    return f"{PERSONAPLEX_URL}/api/chat?{query}"


server = VoiceServer(port=int(os.environ.get("PORT", "3000")))


@server.handler
async def on_call(session):
    fmt = session.audio_format or {}
    if fmt.get("codec", "pcm16") != "pcm16":
        # pcmu (G.711) would need a mu-law decoder; keep the app format at pcm16.
        raise RuntimeError("set the app audio to pcm16 (24000 Hz recommended)")
    session_rate = int(fmt.get("rate", 16_000))

    # A call can pick its own persona/voice: app metadata wins over the environment.
    meta = session.metadata or {}
    text_prompt = str(meta.get("personaplex_text_prompt") or TEXT_PROMPT)
    voice_prompt = str(meta.get("personaplex_voice") or VOICE_PROMPT)

    inbound = asyncio.Queue(maxsize=200)  # float32 samples at MODEL_RATE, from the caller

    def on_frame(frame: bytes, track: int) -> None:
        pcm = np.frombuffer(frame, dtype="<i2").astype(np.float32)
        if GATE_RMS and float(np.sqrt(np.mean(pcm**2))) < GATE_RMS:
            pcm = np.zeros_like(pcm)
        pcm = resample(pcm / 32768.0, session_rate, MODEL_RATE)
        try:
            inbound.put_nowait(pcm)
        except asyncio.QueueFull:  # the model is behind: drop the oldest audio, keep it live
            inbound.get_nowait()
            inbound.put_nowait(pcm)

    session.audio.on_frame(on_frame)

    try:
        async with websockets.connect(
            model_url(text_prompt, voice_prompt),
            max_size=None,
            open_timeout=CONNECT_TIMEOUT,
        ) as model:
            await _bridge(session, model, inbound, session_rate)
    except (OSError, websockets.exceptions.WebSocketException) as e:
        logger.error("PersonaPlex unavailable (%s): %s", PERSONAPLEX_URL, e)
        raise  # the SDK hangs up rather than leaving the caller in silence


async def _bridge(session, model, inbound: asyncio.Queue, session_rate: int) -> None:
    writer = sphn.OpusStreamWriter(MODEL_RATE)  # caller -> model
    reader = sphn.OpusStreamReader(MODEL_RATE)  # model -> caller

    first = await asyncio.wait_for(model.recv(), CONNECT_TIMEOUT)
    if not first or first[0] != KIND_HANDSHAKE:
        raise RuntimeError("PersonaPlex did not send its handshake")
    logger.info("PersonaPlex ready for call %s", session.call_ref)

    async def caller_to_model() -> None:
        pending = np.zeros(0, dtype=np.float32)
        while True:
            pending = np.concatenate([pending, await inbound.get()])
            while pending.size >= CHUNK_SAMPLES:
                writer.append_pcm(pending[:CHUNK_SAMPLES])
                pending = pending[CHUNK_SAMPLES:]
                data = writer.read_bytes()
                if data:
                    await model.send(bytes([KIND_AUDIO]) + data)

    async def model_to_caller() -> None:
        async for message in model:
            if not isinstance(message, (bytes, bytearray)) or not message:
                continue
            kind, payload = message[0], bytes(message[1:])
            if kind == KIND_AUDIO:
                reader.append_bytes(payload)
                pcm = reader.read_pcm()
                if pcm.size:
                    out = resample(pcm.astype(np.float32), MODEL_RATE, session_rate)
                    await session.audio.send(
                        (np.clip(out, -1.0, 1.0) * 32767).astype("<i2").tobytes()
                    )
            elif kind == KIND_TEXT:  # the model's own transcript of what it says
                logger.debug("model: %s", payload.decode("utf-8", "ignore"))

    tasks = [asyncio.create_task(caller_to_model()), asyncio.create_task(model_to_caller())]
    try:
        # Ends when the model closes, the caller hangs up (the SDK closes the session), or the cap hits.
        done, _ = await asyncio.wait(tasks, timeout=MAX_CALL_SECONDS, return_when=asyncio.FIRST_COMPLETED)
        for t in done:
            t.result()
    finally:
        for t in tasks:
            t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
    if not session.ended:
        await session.hangup()


if __name__ == "__main__":
    logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"))
    server.run()
