#!/usr/bin/env bash
# Creates the owner (first user + its workspace) of a self-hosted install. Safe to re-run:
# when the owner exists, nothing changes. The password is never printed unless generated here.
#   ./create-owner.sh you@example.com [--name "Your Name"]
set -euo pipefail

email="${1:?usage: create-owner.sh <email> [--name <name>]}"
shift || true
pw_file="${OWNER_PW_FILE:-owner.pw}"

if [ ! -f "$pw_file" ]; then
  (umask 077; openssl rand -hex 16 > "$pw_file")
  echo "generated a password in $pw_file (readable only by you); sign in with it, then change it"
fi

docker compose exec -T apiserver fonoster-owner create "$email" "$@" < "$pw_file"
